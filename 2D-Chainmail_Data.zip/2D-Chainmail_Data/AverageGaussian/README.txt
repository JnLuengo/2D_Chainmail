Data provided as grace file.

type xydy: x="Rigid-segment coverage", y="Average Gaussian curvature", dy="error in curvature"
