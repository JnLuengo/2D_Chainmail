Data provided as grace files.

+ Fig. 9a = P1vP2.agr
+ Fig. 9b = DistP1.agr + RescalP1.agr
+ Fig. 9c = DistP2.agr + RescalP2.agr
+ Fig. 9d = scalingfactors.agr 

Fig. 9a-c type xy: x="Gaussian curvature", y="CDF"
Fig. 9d type xydy: x="Rigid-segment coverage", y="scaling factor", dy="error in scaling factor"

