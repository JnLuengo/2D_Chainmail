Data provided as grace files.
Labels in filenames: F = "flexible", R = "rigid".

+ For P1 and P2 data, type xydy: x="Rigid-segment coverage", y="Probability of contact", dy="error in probability"
+ For Mean Field (MF) or Model (Fit/Prediction) lines, type xy: x="Rigid-segment coverage", y="Probability of contact"
