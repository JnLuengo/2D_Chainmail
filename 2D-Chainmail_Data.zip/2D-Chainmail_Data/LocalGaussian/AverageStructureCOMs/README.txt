AvrStr_P1.lammpstrj and AvrStr_P2.lammpstrj are lammps files with average structures of P1 and P2 fully-flexible membranes.

KGHeatmap_P1.dat and KGHeatmap_P2.dat are the corresponding heatmaps of Gaussian curvature with the column format:
x coordinate of vertex in membrane | y coordinate of vertex in membrane | Gaussian curvature
