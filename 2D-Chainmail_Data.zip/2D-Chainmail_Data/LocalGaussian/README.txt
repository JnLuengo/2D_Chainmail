Fig. 7 = "AverageStructureCOMs"
Fig. 8 = "Heatmaps"
