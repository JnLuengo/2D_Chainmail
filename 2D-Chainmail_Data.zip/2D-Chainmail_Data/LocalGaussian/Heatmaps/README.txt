Name     Rigid-segment coverage (%)
flex     0
23flex   33
diblock  50
23rigid  66
rigid    100


Heatmap files have the column format:
x coordinate of vertex in membrane | y coordinate of vertex in membrane | Gaussian curvature
