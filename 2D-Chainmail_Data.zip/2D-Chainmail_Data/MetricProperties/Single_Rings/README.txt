b-vs-RgRings.agr type xydxdy x="Rg of single rings", y="Mechanical bond length", dx="error in x", dy="error in y" 
Rg_SingleRings.agr type xydy x="Rigid-segment coverage", y="Rg of single or isolated rings", dy="error"
