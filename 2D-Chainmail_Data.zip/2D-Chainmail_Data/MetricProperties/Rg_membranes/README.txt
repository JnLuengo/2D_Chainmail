type xydy x="Rigid-segment coverage", y="Rg membranes", dy="error" 

