type xydy x="Rigid-segment coverage", y="Eigenvalue normalized", dy="error" 

