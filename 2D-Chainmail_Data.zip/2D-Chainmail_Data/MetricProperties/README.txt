Data provided as grace files.

+ Fig. 4a = Rg_membranes
+ Fig. 4b = Eigenvalues_Membranes
+ Fig. 4c and d = Single_Rings
