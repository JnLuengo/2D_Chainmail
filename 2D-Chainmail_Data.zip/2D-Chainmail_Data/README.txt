Data for "Shape and Size Tunability of Sheets of Interlocked Ring Copolymers"

+ Fig. 4 data in "MetricProperties"
+ Fig. 5 data in "ContactingRegions"
+ Fig. 6 data in "AverageGaussian"
+ Fig. 7 and 8 data in "LocalGaussian"
+ Fig 9 data in "DistributionsGaussian"
